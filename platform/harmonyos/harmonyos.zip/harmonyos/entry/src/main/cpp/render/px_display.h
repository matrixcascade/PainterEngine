#ifndef HARMONY_DISPLAY_H
#define HARMONY_DISPLAY_H
//
#define _GL_CORE_

#include <GLES3/gl3.h>
#include <EGL/egl.h>


#include "../../kernel/PX_Object.h"



typedef  struct
{
    px_void *pHarmonyWindow;
    EGLDisplay display;
    EGLSurface surface;
    EGLContext context;

    GLuint vertexShader;
    GLuint pixelsShader;
    GLuint programObject;
    GLuint vPosition;
    GLuint vTex;
    GLuint renderTexture;
    int32_t width;
    int32_t height;

    px_bool PainterEngineReady;
}PX_HarmonyEngine;

px_bool  PX_HarmonyEngine_InitializeDisplay(PX_HarmonyEngine *engine,px_void *pHarmonyWindow);
px_bool  PX_HarmonyEngine_FreeDisplay(PX_HarmonyEngine *engine);
px_void PX_HarmonyEngine_Render(PX_HarmonyEngine* engine,px_int width,px_int height,px_byte *buffer);
#endif