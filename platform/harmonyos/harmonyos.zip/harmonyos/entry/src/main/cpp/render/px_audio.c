#include "platform/modules/px_audio.h"

px_bool PX_AudioInitialize(PX_SoundPlay *soundPlay)
{
    return  PX_FALSE;
}


void PX_AudioSetVolume(unsigned int volume)
{
    
}
