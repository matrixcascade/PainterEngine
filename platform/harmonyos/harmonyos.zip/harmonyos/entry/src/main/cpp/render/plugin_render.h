/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _PLUGIN_RENDER_H_
#define _PLUGIN_RENDER_H_
#include <native_vsync/native_vsync.h>
#include <string>
#include <unordered_map>
#include <ace/xcomponent/native_interface_xcomponent.h>
#include <napi/native_api.h>

extern "C"
{
    #include "px_display.h"
    #include "PainterEngine_Application.h"
}



class PluginRender {
public:
    explicit PluginRender(std::string &id);
    static PluginRender *GetInstance(std::string &id);
    static OH_NativeXComponent_Callback *GetNXComponentCallback();

    void SetNativeXComponent(OH_NativeXComponent *component);

public:
    // NAPI interface
    napi_value Export(napi_env env, napi_value exports);

    // Exposed to JS developers by NAPI
    static napi_value NapiSwitchAmbient(napi_env env, napi_callback_info info);
    static napi_value NapiSwitchDiffuse(napi_env env, napi_callback_info info);
    static napi_value NapiSwitchSpecular(napi_env env, napi_callback_info info);

    // Callback, called by ACE XComponent
    void OnSurfaceCreated(OH_NativeXComponent *component, void *window);
    void OnSurfaceChanged(OH_NativeXComponent *component, void *window);
    void OnSurfaceDestroyed(OH_NativeXComponent *component, void *window);
    void OnTouchEvent(OH_NativeXComponent* component, void* window);
    void OnMouseEvent(OH_NativeXComponent* component, void* window);
    void OnHoverEvent(OH_NativeXComponent* component, bool isHover);
    void OnFocusEvent(OH_NativeXComponent* component, void* window);
    void OnBlurEvent(OH_NativeXComponent* component, void* window);
    void OnKeyEvent(OH_NativeXComponent* component, void* window);
    void RegisterCallback(OH_NativeXComponent* nativeXComponent);
    
    void OnSurfaceRender(long long now);
public:
    static std::unordered_map<std::string, PluginRender *> instance_;
    static OH_NativeXComponent_Callback callback_;

    // OH_NativeXComponent* component_;
    //EGLCore *eglCore_;
    PX_HarmonyEngine *engine;
    OH_NativeVSync *mVsync;
    void *pwindow;
    std::string id_;
    uint64_t width_;
    uint64_t height_;
    long long last_time_stamp;
    double x_;
    double y_;
private:
    OH_NativeXComponent_Callback m_renderCallback;
    OH_NativeXComponent_MouseEvent_Callback m_mouseCallback;
};

#endif // _PLUGIN_RENDER_H_
